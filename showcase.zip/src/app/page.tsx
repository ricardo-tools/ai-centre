import type { Metadata } from "next";
import Footer from "@/components/Footer";
import V4Hero from "@/sections/v4/V4Hero";
import V4PainPoint from "@/sections/v4/V4PainPoint";
import V4HowItWorks from "@/sections/v4/V4HowItWorks";
import V4Benefits from "@/sections/v4/V4Benefits";
import V4Integration from "@/sections/v4/V4Integration";
import V4SocialProof from "@/sections/v4/V4SocialProof";
import V4Cta from "@/sections/v4/V4Cta";

export const metadata: Metadata = {
  title:
    "Credit Application Writeback — The Complete Picture | ezyCollect by Sidetrade",
  description:
    "The complete credit workflow, automated. Save hours, eliminate errors, and seamlessly sync to NetSuite with Credit Application Writeback.",
};

export default function Home() {
  return (
    <>
      <main>
        <V4Hero />
        <V4PainPoint />
        <V4HowItWorks />
        <V4Benefits />
        <V4Integration />
        <V4SocialProof />
        <V4Cta />
      </main>
      <Footer />
    </>
  );
}
