import type { Metadata } from "next";
import { Jost } from "next/font/google";
import "./globals.css";

const jost = Jost({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700", "800"],
  display: "swap",
  variable: "--font-jost",
});

export const metadata: Metadata = {
  title: "Credit Application Writeback | ezyCollect by Sidetrade",
  description:
    "Automatically sync approved credit application data from ezyCollect into NetSuite. Zero manual data entry, zero errors.",
  icons: {
    icon: "https://3936426.fs1.hubspotusercontent-na1.net/hubfs/3936426/Marketing%20Assets/Logos%20-%20by%20Sidetrade/square_logo_orange_ezycollect_by_sidetrade.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" data-theme="light" className={jost.variable}>
      <body style={{ fontFamily: "var(--font-jost), sans-serif" }}>
        {children}
      </body>
    </html>
  );
}
