"use client";

import { ArrowRight } from "@phosphor-icons/react";
import { useReducedMotion } from "motion/react";
import ScrollReveal from "@/components/ScrollReveal";
import GlowButton from "@/components/v4/GlowButton";
import NoiseOverlay from "@/components/v4/NoiseOverlay";

export default function V4Cta() {
  const prefersReduced = useReducedMotion();

  return (
    <section
      id="book-demo"
      style={{
        position: "relative",
        overflow: "hidden",
        padding: "var(--space-12) var(--space-3)",
        background:
          "linear-gradient(135deg, #FF5A28, #1462D2, #7C3AED, #FF5A28)",
        backgroundSize: "300% 300%",
        animation: prefersReduced
          ? "none"
          : "v4-gradient-shift 8s ease-in-out infinite",
      }}
    >
      <NoiseOverlay opacity={0.02} />

      <div
        style={{
          maxWidth: "var(--section-max-width)",
          marginLeft: "auto",
          marginRight: "auto",
          position: "relative",
          zIndex: 1,
        }}
      >
        <ScrollReveal>
          <div
            style={{
              textAlign: "center",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              gap: "var(--space-4)",
            }}
          >
            <h2
              style={{
                fontSize: "var(--text-5xl)",
                fontWeight: "var(--font-hero)",
                color: "#FFFFFF",
                lineHeight: "var(--leading-tight)",
                maxWidth: "600px",
              }}
            >
              See the Complete Picture
            </h2>
            <p
              style={{
                fontSize: "var(--text-lg)",
                color: "rgba(255, 255, 255, 0.85)",
                maxWidth: "480px",
                lineHeight: "var(--leading-relaxed)",
              }}
            >
              Faster onboarding. Perfect data. Seamless integration. Book a demo
              and see Credit Application Writeback in action.
            </p>
            <div style={{ marginTop: "var(--space-2)" }}>
              <GlowButton
                label="Book a Demo"
                href="#"
                size="large"
                variant="ghost"
                icon={<ArrowRight size={20} />}
              />
            </div>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
