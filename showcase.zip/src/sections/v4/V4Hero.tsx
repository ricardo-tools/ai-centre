"use client";

import { motion, useReducedMotion } from "motion/react";
import { ArrowRight, CaretDown, Lightning } from "@phosphor-icons/react";
import AuroraBackground from "@/components/v4/AuroraBackground";
import GlassCard from "@/components/v4/GlassCard";
import GlowButton from "@/components/v4/GlowButton";
import GradientText from "@/components/v4/GradientText";
import FloatingElement from "@/components/FloatingElement";
import Image from "next/image";

const LOGO_WHITE_URL =
  "https://3936426.fs1.hubspotusercontent-na1.net/hubfs/3936426/Marketing%20Assets/Logos%20-%20by%20Sidetrade/rectangle_logo_white_ezycollect_by_sidetrade.png";

/* ---------- sub-components ---------- */

function FormFieldMini({
  label,
  value,
  delay,
}: {
  label: string;
  value: string;
  delay: number;
}) {
  const prefersReduced = useReducedMotion();

  return (
    <motion.div
      initial={prefersReduced ? undefined : { opacity: 0, x: -12 }}
      animate={{ opacity: 1, x: 0 }}
      transition={
        prefersReduced
          ? { duration: 0 }
          : { duration: 0.4, delay, ease: [0, 0, 0.2, 1] }
      }
      style={{
        padding: "8px 12px",
        borderRadius: "var(--radius-sm)",
        backgroundColor: "rgba(255, 255, 255, 0.04)",
        border: "1px solid var(--v4-border-dark)",
        fontSize: "var(--text-sm)",
        display: "flex",
        justifyContent: "space-between",
        gap: "var(--space-2)",
      }}
    >
      <span style={{ color: "var(--v4-text-light-muted)" }}>{label}</span>
      <span
        style={{
          color: "var(--v4-text-light)",
          fontWeight: "var(--font-nav)",
        }}
      >
        {value}
      </span>
    </motion.div>
  );
}

function SyncBadge() {
  const prefersReduced = useReducedMotion();

  return (
    <motion.div
      initial={
        prefersReduced ? undefined : { opacity: 0, scale: 0.6, y: 8 }
      }
      animate={{ opacity: 1, scale: 1, y: 0 }}
      transition={
        prefersReduced
          ? { duration: 0 }
          : { duration: 0.5, delay: 2.2, type: "spring", stiffness: 180 }
      }
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: "var(--space-1)",
        padding: "8px 16px",
        borderRadius: "var(--radius-full)",
        background: "rgba(16, 185, 129, 0.12)",
        border: "1px solid rgba(16, 185, 129, 0.25)",
        color: "var(--color-success)",
        fontSize: "var(--text-sm)",
        fontWeight: "var(--font-button)",
        marginTop: "var(--space-3)",
        boxShadow: "0 0 20px rgba(16, 185, 129, 0.2)",
      }}
    >
      <div
        style={{
          width: 6,
          height: 6,
          borderRadius: "var(--radius-full)",
          backgroundColor: "var(--color-success)",
          boxShadow: "0 0 8px rgba(16, 185, 129, 0.8)",
        }}
      />
      Synced to NetSuite
    </motion.div>
  );
}

function ProgressBar() {
  const prefersReduced = useReducedMotion();

  return (
    <div
      style={{
        height: 4,
        borderRadius: "var(--radius-full)",
        backgroundColor: "rgba(255, 255, 255, 0.06)",
        overflow: "hidden",
        marginTop: "var(--space-2)",
      }}
    >
      <motion.div
        initial={{ width: prefersReduced ? "100%" : "0%" }}
        animate={{ width: "100%" }}
        transition={
          prefersReduced
            ? { duration: 0 }
            : { duration: 1.2, delay: 1.6, ease: [0, 0, 0.2, 1] }
        }
        style={{
          height: "100%",
          borderRadius: "var(--radius-full)",
          background: "var(--gradient-brand)",
          boxShadow: "0 0 12px rgba(255, 90, 40, 0.5)",
        }}
      />
    </div>
  );
}

/* ---------- Word stagger headline ---------- */

function HeroHeadline() {
  const prefersReduced = useReducedMotion();
  const words = "The Complete Credit Workflow.".split(" ");

  return (
    <h1
      style={{
        fontSize: "var(--text-6xl)",
        fontWeight: "var(--font-hero)",
        color: "var(--v4-text-light)",
        lineHeight: "var(--leading-tight)",
        marginBottom: "var(--space-4)",
        maxWidth: "800px",
        display: "flex",
        flexWrap: "wrap",
        justifyContent: "center",
        gap: "0 0.28em",
      }}
    >
      {words.map((word, i) => (
        <motion.span
          key={i}
          initial={prefersReduced ? undefined : { opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={
            prefersReduced
              ? { duration: 0 }
              : {
                  duration: 0.5,
                  delay: 0.15 + i * 0.08,
                  ease: [0, 0, 0.2, 1],
                }
          }
          style={{ display: "inline-block" }}
        >
          {word}
        </motion.span>
      ))}
      <motion.span
        initial={prefersReduced ? undefined : { opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={
          prefersReduced
            ? { duration: 0 }
            : { duration: 0.6, delay: 0.55, ease: [0, 0, 0.2, 1] }
        }
        style={{ display: "inline-block" }}
      >
        <GradientText
          style={{
            fontSize: "inherit",
            fontWeight: "inherit",
            lineHeight: "inherit",
          }}
        >
          Automated.
        </GradientText>
      </motion.span>
    </h1>
  );
}

/* ---------- Main Hero ---------- */

export default function V4Hero() {
  const prefersReduced = useReducedMotion();

  return (
    <AuroraBackground>
      {/* Transparent floating header */}
      <header
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          zIndex: 200,
          padding: "0 var(--space-3)",
        }}
      >
        <div
          style={{
            maxWidth: "var(--section-max-width)",
            marginLeft: "auto",
            marginRight: "auto",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            height: 72,
          }}
        >
          <motion.a
            href="/"
            style={{ display: "flex", alignItems: "center" }}
            initial={prefersReduced ? undefined : { opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={
              prefersReduced ? { duration: 0 } : { duration: 0.6, delay: 0.8 }
            }
          >
            <Image
              src={LOGO_WHITE_URL}
              alt="ezyCollect by Sidetrade"
              width={160}
              height={32}
              style={{ height: 32, width: "auto" }}
              priority
            />
          </motion.a>
          <motion.div
            initial={prefersReduced ? undefined : { opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={
              prefersReduced ? { duration: 0 } : { duration: 0.6, delay: 0.8 }
            }
          >
            <GlowButton label="Book a Demo" href="#book-demo" />
          </motion.div>
        </div>
      </header>

      {/* Hero content */}
      <div
        style={{
          maxWidth: "var(--section-max-width)",
          marginLeft: "auto",
          marginRight: "auto",
          padding: "160px var(--space-3) var(--space-6)",
          textAlign: "center",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          minHeight: "100vh",
        }}
      >
        {/* Badge */}
        <motion.div
          initial={prefersReduced ? undefined : { opacity: 0, y: 16, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={
            prefersReduced
              ? { duration: 0 }
              : { duration: 0.5, ease: [0, 0, 0.2, 1] }
          }
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: "var(--space-2)",
            padding: "8px 20px",
            borderRadius: "var(--radius-full)",
            border: "1px solid var(--v4-glass-border)",
            background: "var(--v4-glass-bg)",
            backdropFilter: "blur(12px)",
            WebkitBackdropFilter: "blur(12px)",
            color: "var(--v4-text-light-muted)",
            fontSize: "var(--text-sm)",
            fontWeight: "var(--font-nav)",
            marginBottom: "var(--space-5)",
          }}
        >
          <Lightning size={14} weight="fill" style={{ color: "var(--color-primary)" }} />
          Credit Application Writeback
        </motion.div>

        {/* Headline — word stagger */}
        <HeroHeadline />

        {/* Subtitle */}
        <motion.p
          initial={prefersReduced ? undefined : { opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={
            prefersReduced
              ? { duration: 0 }
              : { duration: 0.6, delay: 0.5, ease: [0, 0, 0.2, 1] }
          }
          style={{
            fontSize: "var(--text-lg)",
            color: "var(--v4-text-light-muted)",
            lineHeight: "var(--leading-relaxed)",
            marginBottom: "var(--space-6)",
            maxWidth: "560px",
          }}
        >
          Faster onboarding. Zero transcription errors. Seamless NetSuite
          integration. One feature that solves all three.
        </motion.p>

        {/* CTAs */}
        <motion.div
          initial={prefersReduced ? undefined : { opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={
            prefersReduced
              ? { duration: 0 }
              : { duration: 0.5, delay: 0.65, ease: [0, 0, 0.2, 1] }
          }
          style={{
            display: "flex",
            gap: "var(--space-3)",
            flexWrap: "wrap",
            justifyContent: "center",
            marginBottom: "var(--space-8)",
          }}
        >
          <GlowButton
            label="Book a Demo"
            href="#book-demo"
            size="large"
            icon={<ArrowRight size={20} />}
          />
          <GlowButton
            label="See the Full Picture"
            href="#pain-points"
            variant="ghost"
            size="large"
          />
        </motion.div>

        {/* Glass product demo — materialises with blur-to-clear */}
        <motion.div
          initial={
            prefersReduced
              ? undefined
              : { opacity: 0, y: 40, scale: 0.92, filter: "blur(8px)" }
          }
          animate={{ opacity: 1, y: 0, scale: 1, filter: "blur(0px)" }}
          transition={
            prefersReduced
              ? { duration: 0 }
              : { duration: 1, delay: 0.9, ease: [0, 0, 0.2, 1] }
          }
          style={{ width: "100%", maxWidth: 520 }}
        >
          <FloatingElement amplitude={3} duration={6}>
            <GlassCard
              style={{
                padding: "var(--space-4)",
                boxShadow:
                  "0 8px 48px rgba(0, 0, 0, 0.4), 0 0 0 1px var(--v4-glass-border)",
              }}
            >
              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  gap: "var(--space-2)",
                }}
              >
                {/* Panel header */}
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    marginBottom: "var(--space-1)",
                  }}
                >
                  <span
                    style={{
                      fontSize: "var(--text-xs)",
                      fontWeight: "var(--font-button)",
                      color: "var(--color-primary)",
                      textTransform: "uppercase",
                      letterSpacing: "0.06em",
                    }}
                  >
                    Credit Application → NetSuite
                  </span>
                  <span
                    style={{
                      fontSize: "var(--text-xs)",
                      color: "var(--v4-text-light-muted)",
                    }}
                  >
                    Live
                  </span>
                </div>

                {/* Fields with stagger */}
                <FormFieldMini label="Company" value="Acme Industries Pty Ltd" delay={1.2} />
                <FormFieldMini label="ABN" value="51 824 753 556" delay={1.3} />
                <FormFieldMini label="Credit Limit" value="$50,000" delay={1.4} />
                <FormFieldMini label="Payment Terms" value="Net 30" delay={1.5} />
                <FormFieldMini label="Contact" value="Jane Smith" delay={1.6} />

                {/* Animated progress bar */}
                <ProgressBar />

                {/* Sync badge */}
                <SyncBadge />
              </div>
            </GlassCard>
          </FloatingElement>
        </motion.div>

        {/* Scroll indicator */}
        <motion.div
          initial={prefersReduced ? undefined : { opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={
            prefersReduced ? { duration: 0 } : { duration: 0.5, delay: 2.5 }
          }
          style={{
            marginTop: "var(--space-6)",
            color: "var(--v4-text-light-muted)",
            animation: prefersReduced
              ? "none"
              : "v4-scroll-hint 2s ease-in-out infinite",
          }}
        >
          <CaretDown size={24} />
        </motion.div>
      </div>
    </AuroraBackground>
  );
}
