"use client";

import { ReactNode } from "react";
import { motion, useReducedMotion } from "motion/react";
import Image from "next/image";
import {
  Lightning,
  ShieldCheck,
  ArrowsClockwise,
  Plugs,
} from "@phosphor-icons/react";
import V4Section from "@/components/v4/V4Section";
import ScrollReveal from "@/components/ScrollReveal";
import WordReveal from "@/components/v4/WordReveal";
import StaggerChildren from "@/components/StaggerChildren";

/* ---------- Rich bento card (design-first) ---------- */

function BentoCard({
  icon,
  title,
  description,
  children,
}: {
  icon: ReactNode;
  title: string;
  description: string;
  children?: ReactNode;
}) {
  const prefersReduced = useReducedMotion();

  return (
    <motion.div
      style={{
        background: "var(--v4-bg-dark-elevated)",
        border: "1px solid var(--v4-border-dark)",
        borderRadius: "var(--radius-lg)",
        padding: "var(--space-4)",
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
        overflow: "hidden",
        height: "100%",
        transition: "all 200ms ease",
      }}
      whileHover={
        prefersReduced
          ? {}
          : {
              backgroundColor: "var(--v4-bg-dark-surface)",
              borderColor: "rgba(255, 255, 255, 0.12)",
            }
      }
      transition={{ duration: 0.2 }}
    >
      {/* Top: icon + text */}
      <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-2)" }}>
        <div
          style={{
            width: 40,
            height: 40,
            borderRadius: "var(--radius-md)",
            background: "var(--gradient-brand)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: "#FFFFFF",
            flexShrink: 0,
          }}
        >
          {icon}
        </div>
        <h3
          style={{
            fontSize: "var(--text-lg)",
            fontWeight: "var(--font-heading)",
            color: "var(--v4-text-light)",
            lineHeight: "var(--leading-snug)",
          }}
        >
          {title}
        </h3>
        <p
          style={{
            fontSize: "var(--text-sm)",
            color: "var(--v4-text-light-muted)",
            lineHeight: "var(--leading-normal)",
          }}
        >
          {description}
        </p>
      </div>

      {/* Bottom: visual accent (stat, logo, mini UI) */}
      {children && (
        <div style={{ marginTop: "var(--space-3)" }}>{children}</div>
      )}
    </motion.div>
  );
}

/* ---------- Mini visual elements ---------- */

function HeroStat({ value, label }: { value: string; label: string }) {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "baseline",
        gap: "var(--space-2)",
      }}
    >
      <span
        style={{
          fontSize: "var(--text-3xl)",
          fontWeight: "var(--font-hero)",
          color: "var(--color-primary)",
          lineHeight: 1,
        }}
      >
        {value}
      </span>
      <span
        style={{
          fontSize: "var(--text-xs)",
          color: "var(--v4-text-light-muted)",
        }}
      >
        {label}
      </span>
    </div>
  );
}

function SyncPulse() {
  const prefersReduced = useReducedMotion();

  return (
    <div style={{ display: "flex", alignItems: "center", gap: "var(--space-2)" }}>
      <motion.div
        animate={prefersReduced ? {} : { scale: [1, 1.3, 1], opacity: [0.6, 1, 0.6] }}
        transition={prefersReduced ? {} : { duration: 2, repeat: Infinity, ease: "easeInOut" }}
        style={{
          width: 8,
          height: 8,
          borderRadius: "var(--radius-full)",
          backgroundColor: "var(--color-success)",
          boxShadow: "0 0 6px rgba(16, 185, 129, 0.6)",
        }}
      />
      <span
        style={{
          fontSize: "var(--text-xs)",
          color: "var(--color-success)",
          fontWeight: "var(--font-nav)",
        }}
      >
        Live sync active
      </span>
    </div>
  );
}

function FieldPills() {
  const fields = ["Company", "ABN", "Limit", "Terms", "Contact"];
  return (
    <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
      {fields.map((f) => (
        <span
          key={f}
          style={{
            fontSize: "var(--text-xs)",
            padding: "3px 8px",
            borderRadius: "var(--radius-sm)",
            background: "rgba(255, 255, 255, 0.04)",
            border: "1px solid var(--v4-border-dark)",
            color: "var(--v4-text-light-muted)",
          }}
        >
          {f}
        </span>
      ))}
    </div>
  );
}

/* ---------- Main ---------- */

export default function V4Benefits() {
  const prefersReduced = useReducedMotion();

  return (
    <V4Section dark>
      <ScrollReveal>
        <div style={{ textAlign: "center", marginBottom: "var(--space-8)" }}>
          <p
            style={{
              fontSize: "var(--text-sm)",
              fontWeight: "var(--font-button)",
              color: "var(--color-primary)",
              textTransform: "uppercase",
              letterSpacing: "0.08em",
              marginBottom: "var(--space-3)",
            }}
          >
            Benefits
          </p>
          <WordReveal
            text="Everything you need. Nothing you don't."
            style={{
              fontSize: "var(--text-4xl)",
              fontWeight: "var(--font-hero)",
              color: "var(--v4-text-light)",
              lineHeight: "var(--leading-tight)",
              justifyContent: "center",
            }}
          />
        </div>
      </ScrollReveal>

      <StaggerChildren className="v4-bento-grid" staggerDelay={0.1}>
        {/* Card A — wide: Zero manual entry + hero stat */}
        <BentoCard
          icon={<Lightning size={20} weight="fill" />}
          title="Zero Manual Data Entry"
          description="Approved credit applications sync to NetSuite automatically. Company details, credit limits, payment terms, contacts — written in seconds."
        >
          <HeroStat value="0" label="keystrokes required" />
        </BentoCard>

        {/* Card B — small: Accuracy + animated progress bar */}
        <BentoCard
          icon={<ShieldCheck size={20} />}
          title="100% Accurate"
          description="Every field verified. Every record matched."
        >
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            <div
              style={{
                height: 4,
                borderRadius: "var(--radius-full)",
                background: "rgba(255,255,255,0.06)",
                overflow: "hidden",
              }}
            >
              <motion.div
                animate={
                  prefersReduced
                    ? {}
                    : { width: ["0%", "100%", "100%", "0%"] }
                }
                transition={
                  prefersReduced
                    ? {}
                    : { duration: 3, repeat: Infinity, ease: "easeInOut", times: [0, 0.4, 0.6, 1] }
                }
                style={{
                  height: "100%",
                  borderRadius: "var(--radius-full)",
                  background: "var(--color-success)",
                  boxShadow: "0 0 8px rgba(16, 185, 129, 0.4)",
                  width: "100%",
                }}
              />
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span style={{ fontSize: 10, color: "var(--v4-text-light-muted)" }}>
                5 of 5 fields synced
              </span>
              <span style={{ fontSize: 10, color: "var(--color-success)", fontWeight: "var(--font-button)" }}>
                verified
              </span>
            </div>
          </div>
        </BentoCard>

        {/* Card C — small: Real-time + stat */}
        <BentoCard
          icon={<ArrowsClockwise size={20} />}
          title="Real-Time Sync"
          description="Instant on approval. No batch jobs. No delays."
        >
          <HeroStat value="<1s" label="sync time" />
        </BentoCard>

        {/* Card D — wide: Built for NetSuite + logo top-right + pills */}
        <motion.div
          style={{
            position: "relative",
            background: "var(--v4-bg-dark-elevated)",
            border: "1px solid var(--v4-border-dark)",
            borderRadius: "var(--radius-lg)",
            padding: "var(--space-4)",
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
            overflow: "hidden",
            height: "100%",
            transition: "all 200ms ease",
          }}
          whileHover={
            prefersReduced
              ? {}
              : {
                  backgroundColor: "var(--v4-bg-dark-surface)",
                  borderColor: "rgba(255, 255, 255, 0.12)",
                }
          }
          transition={{ duration: 0.2 }}
        >
          {/* NetSuite logo — top right */}
          <Image
            src="/images/netsuite-logo.png"
            alt="Oracle NetSuite"
            width={133}
            height={37}
            style={{
              position: "absolute",
              top: "var(--space-4)",
              right: "var(--space-5)",
              opacity: 0.65,
              filter: "invert(1) brightness(2)",
            }}
          />

          <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-2)" }}>
            <div
              style={{
                width: 40,
                height: 40,
                borderRadius: "var(--radius-md)",
                background: "var(--gradient-brand)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "#FFFFFF",
                flexShrink: 0,
              }}
            >
              <Plugs size={20} />
            </div>
            <h3
              style={{
                fontSize: "var(--text-lg)",
                fontWeight: "var(--font-heading)",
                color: "var(--v4-text-light)",
                lineHeight: "var(--leading-snug)",
              }}
            >
              Built for NetSuite
            </h3>
            <p
              style={{
                fontSize: "var(--text-sm)",
                color: "var(--v4-text-light-muted)",
                lineHeight: "var(--leading-normal)",
                maxWidth: "70%",
              }}
            >
              Native integration — configurable mapping, audit trail, validation rules. No code.
            </p>
          </div>

          <FieldPills />
        </motion.div>
      </StaggerChildren>
    </V4Section>
  );
}
