"use client";

import { motion, useReducedMotion } from "motion/react";
import V4Section from "@/components/v4/V4Section";
import ScrollReveal from "@/components/ScrollReveal";
import GlassCard from "@/components/v4/GlassCard";
import AnimatedCounter from "@/components/AnimatedCounter";
import WordReveal from "@/components/v4/WordReveal";

function GlowBurst() {
  return (
    <div
      style={{
        position: "absolute",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        width: 120,
        height: 120,
        borderRadius: "50%",
        background:
          "radial-gradient(circle, rgba(255, 90, 40, 0.4) 0%, transparent 70%)",
        animation: "v4-glow-burst 0.8s ease-out 1.6s 1 forwards",
        opacity: 0,
        pointerEvents: "none",
      }}
    />
  );
}

export default function V4SocialProof() {
  const prefersReduced = useReducedMotion();

  return (
    <V4Section dark>
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: "var(--space-6)",
        }}
      >
        {/* Glowing stat with burst */}
        <motion.div
          initial={
            prefersReduced
              ? undefined
              : { opacity: 0, scale: 0.5 }
          }
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, margin: "-48px" }}
          transition={
            prefersReduced
              ? { duration: 0 }
              : {
                  duration: 0.6,
                  type: "spring",
                  stiffness: 100,
                  damping: 12,
                }
          }
          style={{
            textAlign: "center",
            position: "relative",
          }}
        >
          {!prefersReduced && <GlowBurst />}
          <div
            style={{
              fontSize: "var(--text-6xl)",
              fontWeight: "var(--font-hero)",
              color: "var(--color-primary)",
              lineHeight: "var(--leading-tight)",
              textShadow:
                "0 0 40px rgba(255, 90, 40, 0.5), 0 0 80px rgba(255, 90, 40, 0.25)",
              position: "relative",
              zIndex: 1,
            }}
          >
            <AnimatedCounter
              value={100}
              suffix="%"
              duration={2}
              style={{
                fontSize: "inherit",
                fontWeight: "inherit",
                color: "inherit",
              }}
            />
          </div>
          <p
            style={{
              fontSize: "var(--text-lg)",
              color: "var(--v4-text-light-muted)",
              marginTop: "var(--space-2)",
              position: "relative",
              zIndex: 1,
            }}
          >
            of approved applications synced automatically
          </p>
        </motion.div>

        {/* Quote in glass card */}
        <motion.div
          initial={prefersReduced ? undefined : { opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-48px" }}
          transition={
            prefersReduced
              ? { duration: 0 }
              : { duration: 0.7, delay: 0.3, ease: [0.0, 0.0, 0.2, 1] }
          }
          style={{ width: "100%", maxWidth: 640 }}
        >
          <GlassCard
            style={{
              padding: "var(--space-5)",
              textAlign: "center",
            }}
          >
            <span
              style={{
                fontSize: "var(--text-4xl)",
                color: "rgba(255, 90, 40, 0.3)",
                fontFamily: "Georgia, serif",
                lineHeight: 1,
              }}
              aria-hidden="true"
            >
              &ldquo;
            </span>
            <WordReveal
              text="We eliminated four hours of weekly data entry overnight. The accuracy improvement was the real surprise — zero discrepancies between systems since we turned it on."
              as="p"
              staggerDelay={0.015}
              style={{
                fontSize: "var(--text-lg)",
                color: "var(--v4-text-light)",
                lineHeight: "var(--leading-relaxed)",
                fontStyle: "italic",
                justifyContent: "center",
              }}
            />
            <div style={{ marginTop: "var(--space-4)" }}>
              <p
                style={{
                  fontWeight: "var(--font-button)",
                  color: "var(--v4-text-light)",
                  fontSize: "var(--text-base)",
                }}
              >
                Sarah Mitchell
              </p>
              <p
                style={{
                  fontSize: "var(--text-sm)",
                  color: "var(--v4-text-light-muted)",
                }}
              >
                Credit Manager, Wholesale Distribution Co.
              </p>
            </div>
          </GlassCard>
        </motion.div>
      </div>
    </V4Section>
  );
}
