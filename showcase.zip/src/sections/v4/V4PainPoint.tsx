"use client";

import { motion, useReducedMotion } from "motion/react";
import { Clock, XCircle, ArrowsLeftRight } from "@phosphor-icons/react";
import V4Section from "@/components/v4/V4Section";
import ScrollReveal from "@/components/ScrollReveal";

const painPoints = [
  {
    icon: <Clock size={32} weight="duotone" />,
    title: "Manual entry steals time",
    description:
      "Every approved application means 15+ minutes of re-keying into NetSuite. Hours every week, gone.",
    color: "var(--color-primary)",
    entrance: { x: -80, rotate: -4 },
  },
  {
    icon: <XCircle size={32} weight="duotone" />,
    title: "Transcription errors compound",
    description:
      "One wrong digit in a credit limit. One misspelled name. Small errors that ripple through invoicing and compliance.",
    color: "var(--color-danger)",
    entrance: { y: 60, scale: 0.9 },
  },
  {
    icon: <ArrowsLeftRight size={32} weight="duotone" />,
    title: "Disconnected systems drift",
    description:
      "ezyCollect says one thing, NetSuite says another. Without a live connection, your systems diverge.",
    color: "var(--color-secondary)",
    entrance: { x: 80, rotate: 4 },
  },
];

export default function V4PainPoint() {
  const prefersReduced = useReducedMotion();

  return (
    <V4Section
      dark
      id="pain-points"
      style={{ background: "var(--v4-bg-dark-elevated)" }}
    >
      <ScrollReveal>
        <div style={{ textAlign: "center", marginBottom: "var(--space-8)" }}>
          <p
            style={{
              fontSize: "var(--text-sm)",
              fontWeight: "var(--font-button)",
              color: "var(--color-primary)",
              textTransform: "uppercase",
              letterSpacing: "0.08em",
              marginBottom: "var(--space-3)",
            }}
          >
            The Problem
          </p>
          <h2
            style={{
              fontSize: "var(--text-4xl)",
              fontWeight: "var(--font-hero)",
              color: "var(--v4-text-light)",
              lineHeight: "var(--leading-tight)",
              marginBottom: "var(--space-3)",
            }}
          >
            Three problems. One root cause.
          </h2>
          <p
            style={{
              fontSize: "var(--text-lg)",
              color: "var(--v4-text-light-muted)",
              maxWidth: "540px",
              marginLeft: "auto",
              marginRight: "auto",
            }}
          >
            The gap between ezyCollect and NetSuite costs you time, accuracy,
            and visibility — every single day.
          </p>
        </div>
      </ScrollReveal>

      {/* Editorial layout — icon large, minimal chrome */}
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          gap: "var(--space-6)",
          maxWidth: 720,
          marginLeft: "auto",
          marginRight: "auto",
        }}
      >
        {painPoints.map((point, i) => (
          <motion.div
            key={point.title}
            initial={
              prefersReduced
                ? undefined
                : {
                    opacity: 0,
                    x: point.entrance.x ?? 0,
                    y: point.entrance.y ?? 0,
                    rotate: point.entrance.rotate ?? 0,
                    scale: point.entrance.scale ?? 1,
                  }
            }
            whileInView={{ opacity: 1, x: 0, y: 0, rotate: 0, scale: 1 }}
            viewport={{ once: true, margin: "-48px" }}
            transition={
              prefersReduced
                ? { duration: 0 }
                : {
                    duration: 0.7,
                    delay: i * 0.15,
                    type: "spring",
                    stiffness: 80,
                    damping: 15,
                  }
            }
            style={{
              display: "flex",
              alignItems: "flex-start",
              gap: "var(--space-4)",
              padding: "var(--space-4) 0",
              borderBottom:
                i < painPoints.length - 1
                  ? "1px solid var(--v4-border-dark)"
                  : "none",
            }}
          >
            {/* Large icon — no background box, just the icon with color */}
            <div
              style={{
                flexShrink: 0,
                color: point.color,
                marginTop: 4,
                opacity: 0.9,
              }}
            >
              {point.icon}
            </div>

            <div>
              <h3
                style={{
                  fontSize: "var(--text-xl)",
                  fontWeight: "var(--font-heading)",
                  color: "var(--v4-text-light)",
                  marginBottom: "var(--space-2)",
                  lineHeight: "var(--leading-snug)",
                }}
              >
                {point.title}
              </h3>
              <p
                style={{
                  fontSize: "var(--text-base)",
                  color: "var(--v4-text-light-muted)",
                  lineHeight: "var(--leading-relaxed)",
                }}
              >
                {point.description}
              </p>
            </div>
          </motion.div>
        ))}
      </div>
    </V4Section>
  );
}
