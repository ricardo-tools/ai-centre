import V4Section from "@/components/v4/V4Section";
import ScrollReveal from "@/components/ScrollReveal";
import GlassCard from "@/components/v4/GlassCard";
import FieldMappingVisual from "@/components/FieldMappingVisual";

const categories = [
  { label: "Company Details", desc: "Name, ABN, address, industry" },
  { label: "Credit Terms", desc: "Limit, terms, risk rating" },
  { label: "Contacts", desc: "Name, email, phone, role" },
  { label: "Custom Fields", desc: "Any field you need mapped" },
];

export default function V4Integration() {
  return (
    <V4Section dark style={{ background: "var(--v4-bg-dark-elevated)" }}>
      <ScrollReveal>
        <div style={{ textAlign: "center", marginBottom: "var(--space-6)" }}>
          <p
            style={{
              fontSize: "var(--text-sm)",
              fontWeight: "var(--font-button)",
              color: "var(--color-secondary)",
              textTransform: "uppercase",
              letterSpacing: "0.08em",
              marginBottom: "var(--space-3)",
            }}
          >
            Integration
          </p>
          <h2
            style={{
              fontSize: "var(--text-4xl)",
              fontWeight: "var(--font-hero)",
              color: "var(--v4-text-light)",
              lineHeight: "var(--leading-tight)",
              marginBottom: "var(--space-3)",
            }}
          >
            Deep NetSuite Integration
          </h2>
          <p
            style={{
              fontSize: "var(--text-lg)",
              color: "var(--v4-text-light-muted)",
              maxWidth: "600px",
              marginLeft: "auto",
              marginRight: "auto",
            }}
          >
            Every field maps from ezyCollect to NetSuite. Configure it once —
            every approved application flows through automatically.
          </p>
        </div>
      </ScrollReveal>

      <ScrollReveal delay={0.2}>
        <GlassCard style={{ padding: "var(--space-5)" }}>
          <FieldMappingVisual showCheckmarks />
        </GlassCard>
      </ScrollReveal>

      <ScrollReveal delay={0.3}>
        <div
          style={{
            marginTop: "var(--space-5)",
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
            gap: "var(--space-3)",
          }}
        >
          {categories.map((item) => (
            <GlassCard
              key={item.label}
              hover
              style={{ padding: "var(--space-3)" }}
            >
              <h4
                style={{
                  fontSize: "var(--text-sm)",
                  fontWeight: "var(--font-heading)",
                  color: "var(--v4-text-light)",
                  marginBottom: "var(--space-1)",
                }}
              >
                {item.label}
              </h4>
              <p
                style={{
                  fontSize: "var(--text-sm)",
                  color: "var(--v4-text-light-muted)",
                }}
              >
                {item.desc}
              </p>
            </GlassCard>
          ))}
        </div>
      </ScrollReveal>
    </V4Section>
  );
}
