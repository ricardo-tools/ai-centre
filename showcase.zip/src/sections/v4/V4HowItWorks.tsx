"use client";

import { useRef, useState, useEffect } from "react";
import { motion, useReducedMotion, type MotionValue } from "motion/react";
import {
  ClipboardText,
  CheckCircle,
  CloudArrowUp,
  Check,
} from "@phosphor-icons/react";
import NoiseOverlay from "@/components/v4/NoiseOverlay";

const steps = [
  {
    icon: <ClipboardText size={28} />,
    title: "Assess",
    subtitle: "Application submitted",
    description:
      "Customer submits a digital credit application through ezyCollect. Company details, credit limits, payment terms — all captured.",
    accent: "var(--color-primary)",
    visualFields: ["Company Name", "ABN", "Credit Limit", "Payment Terms"],
  },
  {
    icon: <CheckCircle size={28} weight="fill" />,
    title: "Approve",
    subtitle: "Credit team reviews",
    description:
      "Your credit team reviews and approves with one click. Validation ensures every field is complete before sync begins.",
    accent: "var(--color-secondary)",
    visualFields: ["Credit check — passed", "Fields valid — complete", "Limit approved — confirmed", "Ready to sync — queued"],
  },
  {
    icon: <CloudArrowUp size={28} weight="fill" />,
    title: "Sync",
    subtitle: "NetSuite updated instantly",
    description:
      "Approved data flows into NetSuite in real-time. Company record, credit limit, terms, contacts — created and logged.",
    accent: "var(--color-success)",
    visualFields: ["Company — Created", "Limit — $50,000", "Terms — Net 30", "Contact — Added"],
  },
];

function StepVisual({ fields, accent, opacity }: { fields: string[]; accent: string; opacity: number }) {
  return (
    <div
      style={{
        opacity,
        display: "flex",
        flexDirection: "column",
        gap: 8,
        padding: "var(--space-4)",
        borderRadius: "var(--radius-lg)",
        background: "var(--v4-glass-bg)",
        backdropFilter: "blur(8px)",
        border: "1px solid var(--v4-glass-border)",
        width: 240,
        flexShrink: 0,
        transition: "opacity 0.3s ease",
      }}
    >
      {fields.map((field) => (
        <div
          key={field}
          style={{
            padding: "6px 10px",
            borderRadius: "var(--radius-sm)",
            background: "rgba(255,255,255,0.03)",
            fontSize: "var(--text-xs)",
            color: "var(--v4-text-light-muted)",
            borderLeft: `2px solid ${accent}`,
          }}
        >
          {field}
        </div>
      ))}
    </div>
  );
}

function StepView({
  step,
  opacity,
  yOffset,
}: {
  step: (typeof steps)[0];
  opacity: number;
  yOffset: number;
}) {
  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: "var(--space-6)",
        padding: "var(--space-6)",
        opacity,
        transform: `scale(${0.95 + opacity * 0.05}) translateY(${yOffset}px)`,
        transition: "opacity 0.15s ease, transform 0.15s ease",
        pointerEvents: opacity < 0.1 ? "none" : "auto",
      }}
    >
      <div style={{ flex: "1 1 400px", maxWidth: 480, display: "flex", flexDirection: "column", gap: "var(--space-3)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "var(--space-2)" }}>
          <div style={{ color: step.accent }}>{step.icon}</div>
          <span style={{ fontSize: "var(--text-sm)", fontWeight: "var(--font-button)", color: step.accent, textTransform: "uppercase", letterSpacing: "0.06em" }}>
            {step.subtitle}
          </span>
        </div>
        <h3 style={{ fontSize: "var(--text-4xl)", fontWeight: "var(--font-hero)", color: "var(--v4-text-light)", lineHeight: "var(--leading-tight)" }}>
          {step.title}
        </h3>
        <p style={{ fontSize: "var(--text-lg)", color: "var(--v4-text-light-muted)", lineHeight: "var(--leading-relaxed)" }}>
          {step.description}
        </p>
      </div>
      <StepVisual fields={step.visualFields} accent={step.accent} opacity={opacity} />
    </div>
  );
}

function StepIndicators({ activeStep }: { activeStep: number }) {
  const accents = ["var(--color-primary)", "var(--color-secondary)", "var(--color-success)"];
  return (
    <div style={{ position: "absolute", right: 32, top: "50%", transform: "translateY(-50%)", display: "flex", flexDirection: "column", gap: 16, zIndex: 2 }}>
      {accents.map((accent, i) => (
        <div
          key={i}
          style={{
            width: 8,
            height: 8,
            borderRadius: "var(--radius-full)",
            backgroundColor: accent,
            opacity: i === activeStep ? 1 : 0.3,
            boxShadow: i === activeStep ? `0 0 8px ${accent}` : "none",
            transition: "opacity 0.3s ease, box-shadow 0.3s ease",
          }}
        />
      ))}
    </div>
  );
}

export default function V4HowItWorks() {
  const prefersReduced = useReducedMotion();
  const containerRef = useRef<HTMLDivElement>(null);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    function onScroll() {
      const el = containerRef.current;
      if (!el) return;
      const rect = el.getBoundingClientRect();
      const scrollableDistance = el.offsetHeight - window.innerHeight;
      // progress 0 when container top = viewport top
      // progress 1 when container bottom = viewport bottom
      const scrolled = -rect.top;
      const p = Math.max(0, Math.min(1, scrolled / scrollableDistance));
      setProgress(p);
    }
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Step 1: ALREADY VISIBLE at progress 0 (no fade-in).
  // Equal time per step: each gets 1/3 of progress range.
  // Transitions: 5% of progress to cross-fade between steps.
  function stepOpacity(stepIndex: number): number {
    const stepEnd = (stepIndex + 1) / 3;
    const fadeOutStart = stepEnd - 0.05;

    if (stepIndex === 0) {
      // Step 1: fully visible from 0, fades out at 0.28-0.33
      if (progress < fadeOutStart) return 1;
      if (progress < stepEnd) return 1 - (progress - fadeOutStart) / 0.05;
      return 0;
    }

    if (stepIndex === 2) {
      // Step 3: fades in at 0.62-0.67, holds forever
      const fadeInStart = (stepIndex / 3) - 0.02;
      const fadeInEnd = fadeInStart + 0.05;
      if (progress < fadeInStart) return 0;
      if (progress < fadeInEnd) return (progress - fadeInStart) / 0.05;
      return 1;
    }

    // Step 2: fades in at 0.28-0.33, fades out at 0.62-0.67
    const fadeInStart = (stepIndex / 3) - 0.02;
    const fadeInEnd = fadeInStart + 0.05;
    if (progress < fadeInStart) return 0;
    if (progress < fadeInEnd) return (progress - fadeInStart) / 0.05;
    if (progress < fadeOutStart) return 1;
    if (progress < stepEnd) return 1 - (progress - fadeOutStart) / 0.05;
    return 0;
  }

  function stepY(stepIndex: number): number {
    const op = stepOpacity(stepIndex);
    if (stepIndex === 0) {
      // Step 1 starts at y=0 (no entrance), exits upward
      return op >= 1 ? 0 : -15 * (1 - op);
    }
    if (op <= 0) return 20;
    if (op >= 1) return 0;
    return 20 * (1 - op);
  }

  const activeStep = progress < 0.31 ? 0 : progress < 0.64 ? 1 : 2;
  const showBadge = progress > 0.9;

  if (prefersReduced) {
    return (
      <section id="how-it-works" style={{ background: "var(--v4-bg-dark)", position: "relative", overflow: "hidden", padding: "var(--space-10) var(--space-3)" }}>
        <NoiseOverlay opacity={0.03} />
        <div style={{ maxWidth: "var(--section-max-width)", margin: "0 auto", position: "relative", zIndex: 1 }}>
          <div style={{ textAlign: "center", marginBottom: "var(--space-6)" }}>
            <p style={{ fontSize: "var(--text-sm)", fontWeight: "var(--font-button)", color: "var(--color-primary)", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: "var(--space-3)" }}>How It Works</p>
            <h2 style={{ fontSize: "var(--text-4xl)", fontWeight: "var(--font-hero)", color: "var(--v4-text-light)", lineHeight: "var(--leading-tight)" }}>Three steps. Zero manual effort.</h2>
          </div>
          <div className="steps-grid">
            {steps.map((step) => (
              <div key={step.title} style={{ textAlign: "center", display: "flex", flexDirection: "column", alignItems: "center", gap: "var(--space-3)" }}>
                <div style={{ color: step.accent }}>{step.icon}</div>
                <h3 style={{ fontSize: "var(--text-xl)", fontWeight: "var(--font-heading)", color: "var(--v4-text-light)" }}>{step.title}</h3>
                <p style={{ fontSize: "var(--text-base)", color: "var(--v4-text-light-muted)", lineHeight: "var(--leading-normal)", maxWidth: 320 }}>{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <div ref={containerRef} id="how-it-works" style={{ position: "relative", height: "350vh" }}>
      <div style={{ position: "sticky", top: 0, height: "100vh", overflow: "hidden", background: "var(--v4-bg-dark)" }}>
        <NoiseOverlay opacity={0.03} />

        {/* Minimal chip header */}
        <div style={{ position: "absolute", top: 32, left: "50%", transform: "translateX(-50%)", zIndex: 2, display: "inline-flex", alignItems: "center", gap: "var(--space-2)", padding: "6px 16px", borderRadius: "var(--radius-full)", border: "1px solid var(--v4-border-dark)", background: "var(--v4-glass-bg)", backdropFilter: "blur(8px)", fontSize: "var(--text-xs)", fontWeight: "var(--font-button)", color: "var(--v4-text-light-muted)", textTransform: "uppercase", letterSpacing: "0.08em" }}>
          How It Works
        </div>

        {/* Steps */}
        <div style={{ position: "relative", width: "100%", height: "100%" }}>
          {steps.map((step, i) => (
            <StepView key={step.title} step={step} opacity={stepOpacity(i)} yOffset={stepY(i)} />
          ))}
        </div>

        {/* Dots */}
        <StepIndicators activeStep={activeStep} />

        {/* Complete badge */}
        <div
          style={{
            position: "absolute",
            bottom: 40,
            left: "50%",
            transform: "translateX(-50%)",
            opacity: showBadge ? 1 : 0,
            transition: "opacity 0.4s ease",
            display: "flex",
            alignItems: "center",
            gap: "var(--space-2)",
            padding: "8px 20px",
            borderRadius: "var(--radius-full)",
            background: "rgba(16, 185, 129, 0.12)",
            border: "1px solid rgba(16, 185, 129, 0.25)",
            color: "var(--color-success)",
            fontSize: "var(--text-sm)",
            fontWeight: "var(--font-button)",
            zIndex: 2,
          }}
        >
          <Check size={16} weight="bold" />
          Workflow Complete
        </div>
      </div>
    </div>
  );
}
