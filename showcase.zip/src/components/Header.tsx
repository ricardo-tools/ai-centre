import Image from "next/image";
import CtaButton from "./CtaButton";

const LOGO_URL =
  "https://3936426.fs1.hubspotusercontent-na1.net/hubfs/3936426/Marketing%20Assets/Logos%20-%20by%20Sidetrade/rectangle_logo_orange_ezycollect_by_sidetrade.png";

export default function Header() {
  return (
    <header
      style={{
        position: "sticky",
        top: 0,
        zIndex: 200, /* --z-sticky */
        backgroundColor: "var(--color-bg)",
        borderBottom: "1px solid var(--color-border)",
        padding: "0 var(--space-3)",
      }}
    >
      <div
        style={{
          maxWidth: "var(--section-max-width)",
          marginLeft: "auto",
          marginRight: "auto",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          height: 56,
        }}
      >
        <a href="/" style={{ display: "flex", alignItems: "center" }}>
          <Image
            src={LOGO_URL}
            alt="ezyCollect by Sidetrade"
            width={160}
            height={32}
            style={{ height: 32, width: "auto" }}
            priority
          />
        </a>
        <CtaButton label="Book a Demo" href="#book-demo" />
      </div>
    </header>
  );
}
