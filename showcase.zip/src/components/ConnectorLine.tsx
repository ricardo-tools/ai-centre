"use client";

import { motion, useReducedMotion } from "motion/react";

interface ConnectorLineProps {
  orientation?: "horizontal" | "vertical";
  color?: string;
  style?: React.CSSProperties;
}

export default function ConnectorLine({
  orientation = "horizontal",
  color = "var(--color-primary)",
  style,
}: ConnectorLineProps) {
  const prefersReduced = useReducedMotion();

  const isHorizontal = orientation === "horizontal";

  return (
    <svg
      width={isHorizontal ? "100%" : "2"}
      height={isHorizontal ? "2" : "100%"}
      style={{
        overflow: "visible",
        display: "block",
        ...style,
      }}
      preserveAspectRatio="none"
    >
      <motion.line
        x1={0}
        y1={isHorizontal ? 1 : 0}
        x2={isHorizontal ? "100%" : 1}
        y2={isHorizontal ? 1 : "100%"}
        stroke={color}
        strokeWidth={2}
        strokeDasharray="6 4"
        initial={{ pathLength: prefersReduced ? 1 : 0, opacity: prefersReduced ? 1 : 0 }}
        whileInView={{ pathLength: 1, opacity: 1 }}
        viewport={{ once: true, margin: "-48px" }}
        transition={
          prefersReduced
            ? { duration: 0 }
            : { duration: 0.8, ease: [0.0, 0.0, 0.2, 1], delay: 0.3 }
        }
      />
    </svg>
  );
}
