import { ReactNode } from "react";

interface StepCardProps {
  stepNumber: number;
  icon: ReactNode;
  title: string;
  description: string;
}

export default function StepCard({
  stepNumber,
  icon,
  title,
  description,
}: StepCardProps) {
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        textAlign: "center",
        gap: "var(--space-3)",
        position: "relative",
      }}
    >
      <div
        style={{
          width: 56,
          height: 56,
          borderRadius: "var(--radius-full)",
          backgroundColor: "var(--color-primary)",
          color: "#FFFFFF",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: "var(--text-xl)",
          fontWeight: "var(--font-hero)",
          position: "relative",
          zIndex: 1,
        }}
      >
        {stepNumber}
      </div>
      <div
        style={{
          color: "var(--color-primary)",
          marginTop: "var(--space-1)",
        }}
      >
        {icon}
      </div>
      <h3
        style={{
          fontSize: "var(--text-xl)",
          fontWeight: "var(--font-heading)",
          color: "var(--color-text-heading)",
          lineHeight: "var(--leading-snug)",
        }}
      >
        {title}
      </h3>
      <p
        style={{
          fontSize: "var(--text-base)",
          color: "var(--color-text-body)",
          lineHeight: "var(--leading-normal)",
          maxWidth: "320px",
        }}
      >
        {description}
      </p>
    </div>
  );
}
