"use client";

import { motion, useReducedMotion } from "motion/react";
import { ReactNode } from "react";

interface ScrollRevealProps {
  children: ReactNode;
  delay?: number;
  direction?: "up" | "down" | "left" | "right";
  style?: React.CSSProperties;
}

const directionMap = {
  up: { y: 24 },
  down: { y: -24 },
  left: { x: 24 },
  right: { x: -24 },
};

export default function ScrollReveal({
  children,
  delay = 0,
  direction = "up",
  style,
}: ScrollRevealProps) {
  const prefersReduced = useReducedMotion();
  const offset = directionMap[direction];

  return (
    <motion.div
      initial={prefersReduced ? undefined : { opacity: 0, ...offset }}
      whileInView={{ opacity: 1, x: 0, y: 0 }}
      viewport={{ once: true, margin: "-48px" }}
      transition={
        prefersReduced
          ? { duration: 0 }
          : {
              duration: 0.5,
              delay,
              ease: [0.0, 0.0, 0.2, 1],
            }
      }
      style={style}
    >
      {children}
    </motion.div>
  );
}
