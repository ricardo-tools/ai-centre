"use client";

import { motion, useReducedMotion } from "motion/react";
import { ReactNode, Children } from "react";

interface StaggerChildrenProps {
  children: ReactNode;
  staggerDelay?: number;
  className?: string;
  style?: React.CSSProperties;
}

export default function StaggerChildren({
  children,
  staggerDelay = 0.06,
  className,
  style,
}: StaggerChildrenProps) {
  const prefersReduced = useReducedMotion();
  const items = Children.toArray(children);

  return (
    <motion.div
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: "-48px" }}
      variants={{
        hidden: {},
        visible: {
          transition: {
            staggerChildren: prefersReduced ? 0 : staggerDelay,
          },
        },
      }}
      className={className}
      style={style}
    >
      {items.map((child, i) => (
        <motion.div
          key={i}
          variants={{
            hidden: prefersReduced ? { opacity: 1 } : { opacity: 0, y: 20 },
            visible: {
              opacity: 1,
              y: 0,
              transition: {
                duration: prefersReduced ? 0 : 0.4,
                ease: [0.0, 0.0, 0.2, 1],
              },
            },
          }}
        >
          {child}
        </motion.div>
      ))}
    </motion.div>
  );
}
