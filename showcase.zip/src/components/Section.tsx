import { ReactNode } from "react";

interface SectionProps {
  children: ReactNode;
  bgAlt?: boolean;
  id?: string;
  style?: React.CSSProperties;
  noPaddingTop?: boolean;
  noPaddingBottom?: boolean;
}

export default function Section({
  children,
  bgAlt = false,
  id,
  style,
  noPaddingTop,
  noPaddingBottom,
}: SectionProps) {
  return (
    <section
      id={id}
      style={{
        backgroundColor: bgAlt ? "var(--color-bg-alt)" : "var(--color-bg)",
        paddingTop: noPaddingTop ? 0 : "var(--space-8)",
        paddingBottom: noPaddingBottom ? 0 : "var(--space-8)",
        paddingLeft: "var(--space-3)",
        paddingRight: "var(--space-3)",
        ...style,
      }}
    >
      <div
        style={{
          maxWidth: "var(--section-max-width)",
          marginLeft: "auto",
          marginRight: "auto",
        }}
      >
        {children}
      </div>
    </section>
  );
}
