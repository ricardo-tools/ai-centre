import { ReactNode } from "react";

interface CtaButtonProps {
  label: string;
  href?: string;
  variant?: "primary" | "secondary";
  size?: "default" | "large";
  icon?: ReactNode;
  onClick?: () => void;
}

export default function CtaButton({
  label,
  href = "#",
  variant = "primary",
  size = "default",
  icon,
  onClick,
}: CtaButtonProps) {
  const isPrimary = variant === "primary";
  const isLarge = size === "large";

  const styles: React.CSSProperties = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "var(--space-2)",
    padding: isLarge ? "16px 32px" : "12px 24px",
    fontSize: isLarge ? "var(--text-lg)" : "var(--text-base)",
    fontWeight: "var(--font-button)",
    fontFamily: "inherit",
    borderRadius: "var(--radius-md)",
    border: isPrimary ? "2px solid transparent" : "2px solid var(--color-secondary)",
    backgroundColor: isPrimary ? "var(--color-primary)" : "transparent",
    color: isPrimary ? "#FFFFFF" : "var(--color-secondary)",
    cursor: "pointer",
    textDecoration: "none",
    transition: "all 150ms var(--ease-out)",
    lineHeight: 1,
  };

  if (onClick) {
    return (
      <button onClick={onClick} style={styles}>
        {icon}
        {label}
      </button>
    );
  }

  return (
    <a href={href} style={styles}>
      {icon}
      {label}
    </a>
  );
}
