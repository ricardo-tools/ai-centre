import { ReactNode } from "react";

interface SimulatedAppPanelProps {
  variant: "ezycollect" | "netsuite";
  title: string;
  children: ReactNode;
  style?: React.CSSProperties;
}

export default function SimulatedAppPanel({
  variant,
  title,
  children,
  style,
}: SimulatedAppPanelProps) {
  const isEzy = variant === "ezycollect";

  return (
    <div
      style={{
        borderRadius: "var(--radius-lg)",
        border: "1px solid var(--color-border)",
        overflow: "hidden",
        backgroundColor: "var(--color-surface)",
        boxShadow: "0 4px 24px rgba(0, 0, 0, 0.08)",
        ...style,
      }}
    >
      {/* Title bar */}
      <div
        style={{
          background: isEzy ? "var(--color-text-heading)" : "var(--color-brand)",
          padding: "10px 16px",
          display: "flex",
          alignItems: "center",
          gap: "var(--space-2)",
        }}
      >
        {/* Window dots */}
        <div style={{ display: "flex", gap: 6 }}>
          <div
            style={{
              width: 10,
              height: 10,
              borderRadius: "var(--radius-full)",
              backgroundColor: "rgba(255,255,255,0.3)",
            }}
          />
          <div
            style={{
              width: 10,
              height: 10,
              borderRadius: "var(--radius-full)",
              backgroundColor: "rgba(255,255,255,0.3)",
            }}
          />
          <div
            style={{
              width: 10,
              height: 10,
              borderRadius: "var(--radius-full)",
              backgroundColor: "rgba(255,255,255,0.3)",
            }}
          />
        </div>
        <span
          style={{
            color: "#FFFFFF",
            fontSize: "var(--text-sm)",
            fontWeight: "var(--font-button)",
            marginLeft: "var(--space-2)",
          }}
        >
          {title}
        </span>
      </div>
      {/* Content area */}
      <div style={{ padding: "var(--space-3)" }}>{children}</div>
    </div>
  );
}
