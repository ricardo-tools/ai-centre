import { ReactNode } from "react";

interface BenefitCardProps {
  icon: ReactNode;
  title: string;
  description: string;
}

export default function BenefitCard({ icon, title, description }: BenefitCardProps) {
  return (
    <div
      style={{
        backgroundColor: "var(--color-surface)",
        border: "1px solid var(--color-border)",
        borderRadius: "var(--radius-lg)",
        padding: "var(--space-5)",
        display: "flex",
        flexDirection: "column",
        gap: "var(--space-3)",
      }}
    >
      <div
        style={{
          width: 48,
          height: 48,
          borderRadius: "var(--radius-md)",
          backgroundColor: "var(--color-primary-muted)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: "var(--color-primary)",
        }}
      >
        {icon}
      </div>
      <h3
        style={{
          fontSize: "var(--text-xl)",
          fontWeight: "var(--font-heading)",
          color: "var(--color-text-heading)",
          lineHeight: "var(--leading-snug)",
        }}
      >
        {title}
      </h3>
      <p
        style={{
          fontSize: "var(--text-base)",
          color: "var(--color-text-body)",
          lineHeight: "var(--leading-normal)",
        }}
      >
        {description}
      </p>
    </div>
  );
}
