import Image from "next/image";

const LOGO_WHITE_URL =
  "https://3936426.fs1.hubspotusercontent-na1.net/hubfs/3936426/Marketing%20Assets/Logos%20-%20by%20Sidetrade/rectangle_logo_white_ezycollect_by_sidetrade.png";

export default function Footer() {
  return (
    <footer
      style={{
        backgroundColor: "var(--color-text-heading)",
        padding: "var(--space-6) var(--space-3)",
      }}
    >
      <div
        style={{
          maxWidth: "var(--section-max-width)",
          marginLeft: "auto",
          marginRight: "auto",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: "var(--space-4)",
        }}
      >
        <Image
          src={LOGO_WHITE_URL}
          alt="ezyCollect by Sidetrade"
          width={160}
          height={32}
          style={{ height: 32, width: "auto" }}
        />
        <div
          style={{
            display: "flex",
            gap: "var(--space-4)",
            flexWrap: "wrap",
            justifyContent: "center",
          }}
        >
          <a
            href="https://www.ezycollect.com.au"
            target="_blank"
            rel="noopener noreferrer"
            style={{ color: "var(--color-bg-alt)", fontSize: "var(--text-sm)" }}
          >
            ezycollect.com.au
          </a>
          <a
            href="https://www.sidetrade.com"
            target="_blank"
            rel="noopener noreferrer"
            style={{ color: "var(--color-bg-alt)", fontSize: "var(--text-sm)" }}
          >
            sidetrade.com
          </a>
        </div>
        <p
          style={{
            color: "var(--color-text-muted)",
            fontSize: "var(--text-xs)",
          }}
        >
          © 2026 ezyCollect by Sidetrade. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
