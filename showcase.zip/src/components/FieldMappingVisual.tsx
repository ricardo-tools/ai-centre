"use client";

import { motion, useReducedMotion } from "motion/react";
import { Check, ArrowRight } from "@phosphor-icons/react";
import SimulatedAppPanel from "./SimulatedAppPanel";

interface FieldMapping {
  source: string;
  target: string;
}

interface FieldMappingVisualProps {
  fields?: FieldMapping[];
  showCheckmarks?: boolean;
}

const defaultFields: FieldMapping[] = [
  { source: "Company Name", target: "Company Name" },
  { source: "ABN", target: "ABN / Tax ID" },
  { source: "Credit Limit", target: "Credit Limit" },
  { source: "Payment Terms", target: "Payment Terms" },
  { source: "Primary Contact", target: "Contact" },
];

function FieldRow({
  label,
  value,
  delay,
  showCheck,
}: {
  label: string;
  value: string;
  delay: number;
  showCheck?: boolean;
}) {
  const prefersReduced = useReducedMotion();

  return (
    <motion.div
      initial={prefersReduced ? undefined : { opacity: 0, x: -8 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={
        prefersReduced
          ? { duration: 0 }
          : { duration: 0.3, delay, ease: [0.0, 0.0, 0.2, 1] }
      }
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        padding: "8px 12px",
        borderRadius: "var(--radius-sm)",
        backgroundColor: "var(--color-bg-alt)",
        fontSize: "var(--text-sm)",
        gap: "var(--space-2)",
      }}
    >
      <span
        style={{
          color: "var(--color-text-muted)",
          fontWeight: "var(--font-nav)",
          minWidth: 0,
        }}
      >
        {label}
      </span>
      <span
        style={{
          color: "var(--color-text-heading)",
          fontWeight: "var(--font-button)",
          textAlign: "right",
          display: "flex",
          alignItems: "center",
          gap: "var(--space-1)",
        }}
      >
        {value}
        {showCheck && (
          <motion.span
            initial={prefersReduced ? undefined : { opacity: 0, scale: 0 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={
              prefersReduced
                ? { duration: 0 }
                : { duration: 0.3, delay: delay + 0.4, type: "spring" }
            }
            style={{ color: "var(--color-success)", display: "inline-flex" }}
          >
            <Check size={14} weight="bold" />
          </motion.span>
        )}
      </span>
    </motion.div>
  );
}

function AnimatedArrow({ delay }: { delay: number }) {
  const prefersReduced = useReducedMotion();

  return (
    <motion.div
      initial={prefersReduced ? undefined : { opacity: 0, scale: 0.5 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={
        prefersReduced
          ? { duration: 0 }
          : { duration: 0.3, delay, ease: [0.0, 0.0, 0.2, 1] }
      }
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: "var(--color-primary)",
        fontSize: "var(--text-xl)",
        fontWeight: "var(--font-hero)",
      }}
    >
      <ArrowRight size={20} weight="bold" />
    </motion.div>
  );
}

export default function FieldMappingVisual({
  fields = defaultFields,
  showCheckmarks = false,
}: FieldMappingVisualProps) {
  return (
    <div className="field-mapping-layout">
      <SimulatedAppPanel variant="ezycollect" title="ezyCollect">
        <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-2)" }}>
          {fields.map((field, i) => (
            <FieldRow
              key={field.source}
              label="Field"
              value={field.source}
              delay={i * 0.1}
            />
          ))}
        </div>
      </SimulatedAppPanel>

      {/* Connector arrows */}
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-around",
          gap: "var(--space-2)",
          padding: "48px 0",
        }}
      >
        {fields.map((_, i) => (
          <AnimatedArrow key={i} delay={0.2 + i * 0.12} />
        ))}
      </div>

      <SimulatedAppPanel variant="netsuite" title="NetSuite">
        <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-2)" }}>
          {fields.map((field, i) => (
            <FieldRow
              key={field.target}
              label="Field"
              value={field.target}
              delay={0.3 + i * 0.1}
              showCheck={showCheckmarks}
            />
          ))}
        </div>
      </SimulatedAppPanel>
    </div>
  );
}
