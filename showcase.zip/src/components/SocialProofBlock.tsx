import { ReactNode } from "react";

interface SocialProofBlockProps {
  quote: string;
  author: string;
  role: string;
  stat?: {
    value: ReactNode;
    label: string;
  };
}

export default function SocialProofBlock({
  quote,
  author,
  role,
  stat,
}: SocialProofBlockProps) {
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        gap: "var(--space-5)",
        alignItems: "center",
      }}
    >
      {stat && (
        <div style={{ textAlign: "center" }}>
          <div
            style={{
              fontSize: "var(--text-5xl)",
              fontWeight: "var(--font-hero)",
              color: "var(--color-primary)",
              lineHeight: "var(--leading-tight)",
            }}
          >
            {stat.value}
          </div>
          <p
            style={{
              fontSize: "var(--text-lg)",
              color: "var(--color-text-muted)",
              marginTop: "var(--space-2)",
            }}
          >
            {stat.label}
          </p>
        </div>
      )}
      <blockquote
        style={{
          maxWidth: "640px",
          textAlign: "center",
          position: "relative",
          padding: "0 var(--space-5)",
        }}
      >
        <span
          style={{
            position: "absolute",
            top: -16,
            left: 0,
            fontSize: "var(--text-6xl)",
            color: "var(--color-primary-muted)",
            lineHeight: 1,
            fontWeight: "var(--font-hero)",
            fontFamily: "Georgia, serif",
          }}
          aria-hidden="true"
        >
          &ldquo;
        </span>
        <p
          style={{
            fontSize: "var(--text-lg)",
            color: "var(--color-text-body)",
            lineHeight: "var(--leading-relaxed)",
            fontStyle: "italic",
          }}
        >
          {quote}
        </p>
        <footer
          style={{
            marginTop: "var(--space-3)",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: "var(--space-1)",
          }}
        >
          <cite
            style={{
              fontWeight: "var(--font-button)",
              color: "var(--color-text-heading)",
              fontStyle: "normal",
              fontSize: "var(--text-base)",
            }}
          >
            {author}
          </cite>
          <span
            style={{
              fontSize: "var(--text-sm)",
              color: "var(--color-text-muted)",
            }}
          >
            {role}
          </span>
        </footer>
      </blockquote>
    </div>
  );
}
