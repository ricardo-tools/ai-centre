"use client";

import { motion, useReducedMotion } from "motion/react";
import { ReactNode } from "react";

interface GlassCardProps {
  children: ReactNode;
  variant?: "dark" | "light";
  hover?: boolean;
  style?: React.CSSProperties;
  className?: string;
}

export default function GlassCard({
  children,
  variant = "dark",
  hover = false,
  style,
  className,
}: GlassCardProps) {
  const prefersReduced = useReducedMotion();
  const isDark = variant === "dark";

  const baseStyles: React.CSSProperties = {
    background: isDark ? "var(--v4-glass-bg)" : "var(--v4-glass-bg-light)",
    backdropFilter: "blur(16px)",
    WebkitBackdropFilter: "blur(16px)",
    border: `1px solid ${isDark ? "var(--v4-glass-border)" : "var(--v4-glass-border-light)"}`,
    borderRadius: "var(--radius-lg)",
    padding: "var(--space-4)",
    ...style,
  };

  if (!hover || prefersReduced) {
    return (
      <div style={baseStyles} className={className}>
        {children}
      </div>
    );
  }

  return (
    <motion.div
      style={baseStyles}
      className={className}
      whileHover={{
        y: -4,
        boxShadow: isDark
          ? "0 0 20px rgba(255, 90, 40, 0.15), 0 8px 32px rgba(0, 0, 0, 0.3)"
          : "0 8px 32px rgba(0, 0, 0, 0.12)",
      }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
    >
      {children}
    </motion.div>
  );
}
