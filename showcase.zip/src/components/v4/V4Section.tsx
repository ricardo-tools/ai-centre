import { ReactNode } from "react";
import NoiseOverlay from "./NoiseOverlay";

interface V4SectionProps {
  children: ReactNode;
  dark?: boolean;
  gradient?: string;
  lightTinted?: boolean;
  id?: string;
  style?: React.CSSProperties;
  noiseOpacity?: number;
}

export default function V4Section({
  children,
  dark = false,
  gradient,
  lightTinted = false,
  id,
  style,
  noiseOpacity,
}: V4SectionProps) {
  const bg = gradient
    ? gradient
    : dark
      ? "var(--v4-bg-dark)"
      : lightTinted
        ? "var(--v4-bg-light-tinted)"
        : "var(--color-bg)";

  return (
    <section
      id={id}
      style={{
        background: bg,
        position: "relative",
        overflow: "hidden",
        padding: "var(--space-10) var(--space-3)",
        ...style,
      }}
    >
      {(dark || gradient) && <NoiseOverlay opacity={noiseOpacity ?? 0.03} />}
      <div
        style={{
          maxWidth: "var(--section-max-width)",
          marginLeft: "auto",
          marginRight: "auto",
          position: "relative",
          zIndex: 1,
        }}
      >
        {children}
      </div>
    </section>
  );
}
