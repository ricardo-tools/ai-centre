"use client";

import { motion, useReducedMotion } from "motion/react";

interface WordRevealProps {
  text: string;
  as?: "h1" | "h2" | "h3" | "p";
  style?: React.CSSProperties;
  staggerDelay?: number;
}

export default function WordReveal({
  text,
  as: Tag = "h2",
  style,
  staggerDelay = 0.04,
}: WordRevealProps) {
  const prefersReduced = useReducedMotion();
  const words = text.split(" ");

  if (prefersReduced) {
    return <Tag style={style}>{text}</Tag>;
  }

  return (
    <Tag style={{ ...style, display: "flex", flexWrap: "wrap" }}>
      <motion.span
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-48px" }}
        variants={{
          hidden: {},
          visible: {
            transition: { staggerChildren: staggerDelay },
          },
        }}
        style={{ display: "flex", flexWrap: "wrap" }}
      >
        {words.map((word, i) => (
          <motion.span
            key={`${word}-${i}`}
            variants={{
              hidden: { opacity: 0, y: 12 },
              visible: {
                opacity: 1,
                y: 0,
                transition: {
                  duration: 0.4,
                  ease: [0.0, 0.0, 0.2, 1],
                },
              },
            }}
            style={{ display: "inline-block", marginRight: "0.3em" }}
          >
            {word}
          </motion.span>
        ))}
      </motion.span>
    </Tag>
  );
}
