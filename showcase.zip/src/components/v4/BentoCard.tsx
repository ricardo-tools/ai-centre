"use client";

import { motion, useReducedMotion } from "motion/react";
import { ReactNode } from "react";

interface BentoCardProps {
  icon: ReactNode;
  title: string;
  description: string;
  children?: ReactNode;
}

export default function BentoCard({
  icon,
  title,
  description,
  children,
}: BentoCardProps) {
  const prefersReduced = useReducedMotion();

  const hoverAnimation = prefersReduced
    ? {}
    : {
        backgroundColor: "var(--v4-bg-dark-surface)",
        borderColor: "rgba(255, 255, 255, 0.12)",
      };

  return (
    <motion.div
      style={{
        background: "var(--v4-bg-dark-elevated)",
        border: "1px solid var(--v4-border-dark)",
        borderRadius: "var(--radius-lg)",
        padding: "var(--space-4)",
        display: "flex",
        flexDirection: "column",
        gap: "var(--space-2)",
        overflow: "hidden",
        height: "100%",
        transition: "all 200ms ease",
      }}
      whileHover={hoverAnimation}
      transition={{ duration: 0.2 }}
    >
      <div
        style={{
          width: 40,
          height: 40,
          borderRadius: "var(--radius-md)",
          background: "var(--gradient-brand)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: "#FFFFFF",
          flexShrink: 0,
        }}
      >
        {icon}
      </div>
      <h3
        style={{
          fontSize: "var(--text-lg)",
          fontWeight: "var(--font-heading)",
          color: "var(--v4-text-light)",
          lineHeight: "var(--leading-snug)",
        }}
      >
        {title}
      </h3>
      <p
        style={{
          fontSize: "var(--text-sm)",
          color: "var(--v4-text-light-muted)",
          lineHeight: "var(--leading-normal)",
        }}
      >
        {description}
      </p>
      {children}
    </motion.div>
  );
}
