import { ReactNode } from "react";

interface GradientTextProps {
  children: ReactNode;
  gradient?: string;
  as?: "span" | "h1" | "h2" | "h3";
  style?: React.CSSProperties;
}

export default function GradientText({
  children,
  gradient = "var(--gradient-brand)",
  as: Tag = "span",
  style,
}: GradientTextProps) {
  return (
    <Tag
      style={{
        backgroundImage: gradient,
        WebkitBackgroundClip: "text",
        WebkitTextFillColor: "transparent",
        backgroundClip: "text",
        ...style,
      }}
    >
      {children}
    </Tag>
  );
}
