"use client";

import { useReducedMotion } from "motion/react";
import { ReactNode, useId } from "react";

interface AuroraBackgroundProps {
  children: ReactNode;
  style?: React.CSSProperties;
}

interface LineConfig {
  top: string;
  gradient: string;
  animation: string;
  duration: string;
  opacity: number;
  height?: number;
}

// Element is 200% wide (left:-50% to right:-50%), viewport sees ~25%-75%.
// Flutter: alpha waves in the gradient handle the brightness variation.
// Element opacity is HIGH (0.5-0.9) so lines are actually visible. Height 2-3px for presence.
const meshLines: LineConfig[] = [
  // Orange cluster — upper (dialled back: 0.10-0.35 opacity)
  { top: "18%", gradient: "linear-gradient(90deg, transparent 3%, rgba(255,90,40,0.6) 8%, rgba(255,90,40,0.9) 18%, rgba(255,90,40,0.5) 28%, rgba(255,90,40,0.8) 40%, rgba(255,90,40,0.5) 52%, rgba(255,90,40,0.85) 64%, rgba(255,90,40,0.55) 76%, rgba(255,90,40,0.75) 86%, rgba(255,90,40,0.5) 93%, transparent 97%)", animation: "v4-mesh-drift-1", duration: "11s", opacity: 0.35, height: 2 },
  { top: "22%", gradient: "linear-gradient(90deg, transparent 4%, rgba(255,90,40,0.45) 10%, rgba(255,90,40,0.7) 24%, rgba(255,90,40,0.4) 36%, rgba(255,90,40,0.65) 48%, rgba(255,90,40,0.4) 60%, rgba(255,90,40,0.7) 72%, rgba(255,90,40,0.45) 84%, rgba(255,90,40,0.5) 92%, transparent 96%)", animation: "v4-mesh-drift-3", duration: "14s", opacity: 0.2, height: 1 },
  { top: "25%", gradient: "linear-gradient(90deg, transparent 5%, rgba(255,90,40,0.4) 12%, rgba(255,90,40,0.6) 26%, rgba(255,90,40,0.35) 40%, rgba(255,90,40,0.55) 54%, rgba(255,90,40,0.35) 66%, rgba(255,90,40,0.6) 78%, rgba(255,90,40,0.4) 90%, transparent 95%)", animation: "v4-mesh-drift-1", duration: "16s", opacity: 0.15, height: 1 },
  { top: "28%", gradient: "linear-gradient(90deg, transparent 4%, rgba(255,130,80,0.4) 12%, rgba(255,130,80,0.6) 28%, rgba(255,130,80,0.35) 42%, rgba(255,130,80,0.55) 56%, rgba(255,130,80,0.35) 70%, rgba(255,130,80,0.5) 84%, rgba(255,130,80,0.35) 92%, transparent 96%)", animation: "v4-mesh-drift-3", duration: "13s", opacity: 0.12, height: 1 },

  // Blue cluster — mid-lower
  { top: "50%", gradient: "linear-gradient(90deg, transparent 3%, rgba(20,98,210,0.55) 8%, rgba(20,98,210,0.85) 20%, rgba(20,98,210,0.5) 32%, rgba(20,98,210,0.8) 44%, rgba(20,98,210,0.5) 56%, rgba(20,98,210,0.85) 68%, rgba(20,98,210,0.55) 80%, rgba(20,98,210,0.7) 90%, rgba(20,98,210,0.5) 94%, transparent 97%)", animation: "v4-mesh-drift-2", duration: "15s", opacity: 0.3, height: 2 },
  { top: "53%", gradient: "linear-gradient(90deg, transparent 5%, rgba(20,98,210,0.4) 12%, rgba(20,98,210,0.65) 26%, rgba(20,98,210,0.4) 40%, rgba(20,98,210,0.6) 52%, rgba(20,98,210,0.4) 64%, rgba(20,98,210,0.65) 76%, rgba(20,98,210,0.45) 88%, rgba(20,98,210,0.4) 93%, transparent 96%)", animation: "v4-mesh-drift-2", duration: "12s", opacity: 0.18, height: 1 },
  { top: "56%", gradient: "linear-gradient(90deg, transparent 4%, rgba(20,98,210,0.35) 10%, rgba(20,98,210,0.55) 26%, rgba(20,98,210,0.3) 40%, rgba(20,98,210,0.5) 54%, rgba(20,98,210,0.3) 68%, rgba(20,98,210,0.55) 80%, rgba(20,98,210,0.35) 90%, transparent 96%)", animation: "v4-mesh-drift-3", duration: "18s", opacity: 0.12, height: 1 },
  { top: "59%", gradient: "linear-gradient(90deg, transparent 5%, rgba(66,165,245,0.35) 14%, rgba(66,165,245,0.55) 28%, rgba(66,165,245,0.3) 42%, rgba(66,165,245,0.5) 56%, rgba(66,165,245,0.3) 70%, rgba(66,165,245,0.5) 82%, rgba(66,165,245,0.3) 92%, transparent 95%)", animation: "v4-mesh-drift-1", duration: "14s", opacity: 0.10, height: 1 },

  // Violet cluster — mid
  { top: "38%", gradient: "linear-gradient(90deg, transparent 3%, rgba(124,58,237,0.5) 10%, rgba(124,58,237,0.75) 22%, rgba(124,58,237,0.45) 34%, rgba(124,58,237,0.7) 46%, rgba(124,58,237,0.4) 58%, rgba(124,58,237,0.7) 70%, rgba(124,58,237,0.5) 82%, rgba(124,58,237,0.45) 92%, transparent 97%)", animation: "v4-mesh-drift-3", duration: "17s", opacity: 0.25, height: 2 },
  { top: "42%", gradient: "linear-gradient(90deg, transparent 5%, rgba(124,58,237,0.35) 14%, rgba(124,58,237,0.55) 28%, rgba(124,58,237,0.3) 42%, rgba(124,58,237,0.5) 56%, rgba(124,58,237,0.3) 70%, rgba(124,58,237,0.55) 82%, rgba(124,58,237,0.35) 92%, transparent 95%)", animation: "v4-mesh-drift-1", duration: "20s", opacity: 0.15, height: 1 },

  // Cross-color accent lines
  { top: "33%", gradient: "linear-gradient(90deg, transparent 3%, rgba(255,90,40,0.4) 12%, rgba(255,90,40,0.2) 24%, rgba(124,58,237,0.4) 36%, rgba(124,58,237,0.2) 48%, rgba(20,98,210,0.4) 60%, rgba(20,98,210,0.2) 72%, rgba(255,90,40,0.35) 84%, rgba(255,90,40,0.2) 93%, transparent 97%)", animation: "v4-mesh-drift-1", duration: "22s", opacity: 0.15, height: 1 },
  { top: "64%", gradient: "linear-gradient(90deg, transparent 5%, rgba(20,98,210,0.3) 14%, rgba(20,98,210,0.15) 28%, rgba(255,90,40,0.35) 42%, rgba(255,90,40,0.15) 56%, rgba(20,98,210,0.3) 70%, rgba(20,98,210,0.15) 82%, rgba(124,58,237,0.25) 92%, transparent 95%)", animation: "v4-mesh-drift-2", duration: "19s", opacity: 0.10, height: 1 },
];

export default function AuroraBackground({ children, style }: AuroraBackgroundProps) {
  const prefersReduced = useReducedMotion();
  const noiseId = useId().replace(/:/g, "");

  return (
    <div
      data-v4-aurora
      style={{
        position: "relative",
        overflow: "hidden",
        background: "#0A0E27",
        ...style,
      }}
    >
      {/* Soft ambient washes */}
      <div
        style={{
          position: "absolute", inset: 0, pointerEvents: "none",
          background: "radial-gradient(ellipse 90% 50% at 50% 35%, rgba(255,90,40,0.05) 0%, transparent 70%)",
        }}
        aria-hidden="true"
      />
      <div
        style={{
          position: "absolute", inset: 0, pointerEvents: "none",
          background: "radial-gradient(ellipse 70% 40% at 30% 55%, rgba(20,98,210,0.04) 0%, transparent 70%)",
        }}
        aria-hidden="true"
      />

      {/* Mesh lines — full width, extending past edges */}
      <div
        style={{ position: "absolute", inset: 0, overflow: "hidden", pointerEvents: "none" }}
        aria-hidden="true"
      >
        {meshLines.map((line, i) => (
          <div
            key={i}
            style={{
              position: "absolute",
              left: "-50%",
              right: "-50%",
              top: line.top,
              height: line.height ?? 1,
              background: line.gradient,
              opacity: line.opacity,
              animation: prefersReduced ? "none" : `${line.animation} ${line.duration} ease-in-out infinite`,
              willChange: "transform",
              pointerEvents: "none",
            }}
          />
        ))}

        {/* Diffuse glow bands behind the line clusters */}
        <div
          style={{
            position: "absolute", left: "-50%", right: "-50%", top: "18%",
            height: 100, filter: "blur(30px)", pointerEvents: "none",
            background: "linear-gradient(90deg, transparent, rgba(255,90,40,0.025) 25%, rgba(255,90,40,0.04) 50%, rgba(255,90,40,0.025) 75%, transparent)",
            animation: prefersReduced ? "none" : "v4-mesh-drift-1 25s ease-in-out infinite",
          }}
        />
        <div
          style={{
            position: "absolute", left: "-50%", right: "-50%", top: "46%",
            height: 80, filter: "blur(25px)", pointerEvents: "none",
            background: "linear-gradient(90deg, transparent, rgba(20,98,210,0.025) 30%, rgba(124,58,237,0.03) 60%, transparent)",
            animation: prefersReduced ? "none" : "v4-mesh-drift-2 28s ease-in-out infinite",
          }}
        />

        {/* Beams removed — full-width lines only */}
      </div>

      {/* Bottom vignette */}
      <div
        style={{
          position: "absolute", bottom: 0, left: 0, right: 0, height: "30%",
          background: "linear-gradient(transparent, #0A0E27)", pointerEvents: "none",
        }}
        aria-hidden="true"
      />

      {/* Noise texture */}
      <svg
        style={{
          position: "absolute", inset: 0, width: "100%", height: "100%",
          pointerEvents: "none", opacity: 0.03, mixBlendMode: "overlay",
        }}
        aria-hidden="true"
      >
        <filter id={`noise-${noiseId}`}>
          <feTurbulence type="fractalNoise" baseFrequency="0.65" numOctaves={3} stitchTiles="stitch" />
          <feColorMatrix type="saturate" values="0" />
        </filter>
        <rect width="100%" height="100%" filter={`url(#noise-${noiseId})`} />
      </svg>

      {/* Content */}
      <div style={{ position: "relative", zIndex: 1 }}>{children}</div>
    </div>
  );
}
