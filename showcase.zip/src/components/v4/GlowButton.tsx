"use client";

import { motion, useReducedMotion } from "motion/react";
import { ReactNode } from "react";

interface GlowButtonProps {
  label: string;
  href?: string;
  onClick?: () => void;
  size?: "default" | "large";
  variant?: "primary" | "ghost";
  icon?: ReactNode;
}

export default function GlowButton({
  label,
  href = "#",
  onClick,
  size = "default",
  variant = "primary",
  icon,
}: GlowButtonProps) {
  const prefersReduced = useReducedMotion();
  const isPrimary = variant === "primary";
  const isLarge = size === "large";

  const styles: React.CSSProperties = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "var(--space-2)",
    padding: isLarge ? "16px 36px" : "12px 28px",
    fontSize: isLarge ? "var(--text-lg)" : "var(--text-base)",
    fontWeight: "var(--font-button)",
    fontFamily: "inherit",
    borderRadius: "var(--radius-md)",
    border: isPrimary ? "none" : "1px solid rgba(255, 255, 255, 0.3)",
    backgroundColor: isPrimary
      ? "var(--color-primary)"
      : "rgba(255, 255, 255, 0.08)",
    color: "#FFFFFF",
    cursor: "pointer",
    textDecoration: "none",
    lineHeight: 1,
    boxShadow: isPrimary ? "var(--v4-glow-orange)" : "none",
    backdropFilter: isPrimary ? "none" : "blur(8px)",
    WebkitBackdropFilter: isPrimary ? "none" : "blur(8px)",
  };

  const hoverAnimation = prefersReduced
    ? {}
    : {
        scale: 1.03,
        boxShadow: isPrimary
          ? "0 0 48px rgba(255, 90, 40, 0.6)"
          : "0 0 24px rgba(255, 255, 255, 0.15)",
      };

  const tapAnimation = prefersReduced ? {} : { scale: 0.97 };

  const Tag = onClick ? motion.button : motion.a;
  const props = onClick
    ? { onClick, style: styles }
    : { href, style: styles };

  return (
    <Tag
      {...props}
      whileHover={hoverAnimation}
      whileTap={tapAnimation}
      transition={{ type: "spring", stiffness: 400, damping: 20 }}
    >
      {icon}
      {label}
    </Tag>
  );
}
