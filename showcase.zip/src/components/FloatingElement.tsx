"use client";

import { motion, useReducedMotion } from "motion/react";
import { ReactNode } from "react";

interface FloatingElementProps {
  children: ReactNode;
  amplitude?: number;
  duration?: number;
  delay?: number;
  style?: React.CSSProperties;
}

export default function FloatingElement({
  children,
  amplitude = 4,
  duration = 3,
  delay = 0,
  style,
}: FloatingElementProps) {
  const prefersReduced = useReducedMotion();

  if (prefersReduced) {
    return <div style={style}>{children}</div>;
  }

  return (
    <motion.div
      animate={{
        y: [-amplitude, amplitude, -amplitude],
      }}
      transition={{
        duration,
        repeat: Infinity,
        ease: "easeInOut",
        delay,
      }}
      style={style}
    >
      {children}
    </motion.div>
  );
}
