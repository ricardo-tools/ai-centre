import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "3936426.fs1.hubspotusercontent-na1.net",
        pathname: "/hubfs/**",
      },
    ],
  },
};

export default nextConfig;
